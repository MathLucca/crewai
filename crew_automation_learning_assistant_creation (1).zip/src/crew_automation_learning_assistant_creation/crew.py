from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task


@CrewBase
class CrewAutomationLearningAssistantCreationCrew():
    """CrewAutomationLearningAssistantCreation crew"""

    @agent
    def chat_interface(self) -> Agent:
        return Agent(
            config=self.agents_config['chat_interface'],
            tools=[],
        )

    @agent
    def memory_manager(self) -> Agent:
        return Agent(
            config=self.agents_config['memory_manager'],
            tools=[],
        )

    @agent
    def dialogue_flow(self) -> Agent:
        return Agent(
            config=self.agents_config['dialogue_flow'],
            tools=[],
        )

    @agent
    def language_adaptation(self) -> Agent:
        return Agent(
            config=self.agents_config['language_adaptation'],
            tools=[],
        )

    @agent
    def orchestrator(self) -> Agent:
        return Agent(
            config=self.agents_config['orchestrator'],
            tools=[],
        )


    @task
    def collect_and_forward_messages(self) -> Task:
        return Task(
            config=self.tasks_config['collect_and_forward_messages'],
            tools=[],
        )

    @task
    def store_conversation_history(self) -> Task:
        return Task(
            config=self.tasks_config['store_conversation_history'],
            tools=[],
        )

    @task
    def manage_transition_steps(self) -> Task:
        return Task(
            config=self.tasks_config['manage_transition_steps'],
            tools=[],
        )

    @task
    def evaluate_and_adapt_language(self) -> Task:
        return Task(
            config=self.tasks_config['evaluate_and_adapt_language'],
            tools=[],
        )

    @task
    def coordinate_overall_process(self) -> Task:
        return Task(
            config=self.tasks_config['coordinate_overall_process'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the CrewAutomationLearningAssistantCreation crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
